import React from 'react';
import './App.css';

function App() {
  return (
    <div className="App">
      <h1>Fueled by Hustle. Driven by Hustle.</h1>
      <p>Hustlehalic Official Launch Coming Soon</p>
    </div>
  );
}

export default App;
